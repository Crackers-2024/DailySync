const { GarminConnect: GarminConnect } = require('@gooin/garmin-connect');

export type GarminClientType = typeof GarminConnect
